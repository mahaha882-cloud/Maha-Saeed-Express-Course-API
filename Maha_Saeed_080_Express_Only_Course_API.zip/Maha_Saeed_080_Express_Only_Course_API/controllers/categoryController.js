const { categories } = require('../data/store');

exports.createCategory = (req, res) => {
  const { name, description } = req.body;
  if (!name || !String(name).trim()) {
    return res.status(400).json({ success: false, message: 'Category name is required' });
  }
  if (categories.some(item => item.name.toLowerCase() === String(name).trim().toLowerCase())) {
    return res.status(409).json({ success: false, message: 'Category already exists' });
  }
  const category = {
    id: String(Date.now()) + String(Math.floor(Math.random() * 1000)),
    name: String(name).trim(),
    description: description ? String(description).trim() : ''
  };
  categories.push(category);
  return res.status(201).json({ success: true, message: 'Category created successfully', category });
};

exports.getCategories = (req, res) => {
  res.status(200).json({ success: true, count: categories.length, categories });
};

exports.getCategoryById = (req, res) => {
  const category = categories.find(item => item.id === req.params.id);
  if (!category) return res.status(404).json({ success: false, message: 'Category not found' });
  res.status(200).json({ success: true, category });
};

exports.updateCategory = (req, res) => {
  const category = categories.find(item => item.id === req.params.id);
  if (!category) return res.status(404).json({ success: false, message: 'Category not found' });
  const { name, description } = req.body;
  if (name !== undefined && !String(name).trim()) {
    return res.status(400).json({ success: false, message: 'Category name cannot be empty' });
  }
  if (name !== undefined) category.name = String(name).trim();
  if (description !== undefined) category.description = String(description).trim();
  res.status(200).json({ success: true, message: 'Category updated successfully', category });
};

exports.deleteCategory = (req, res) => {
  const index = categories.findIndex(item => item.id === req.params.id);
  if (index === -1) return res.status(404).json({ success: false, message: 'Category not found' });
  const deleted = categories.splice(index, 1)[0];
  res.status(200).json({ success: true, message: 'Category deleted successfully', category: deleted });
};
