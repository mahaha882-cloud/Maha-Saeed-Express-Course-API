const { courses, categories } = require('../data/store');

exports.createCourse = (req, res) => {
  const { title, description, instructor, categoryId, price } = req.body;
  if (!title || !instructor || !categoryId) {
    return res.status(400).json({
      success: false,
      message: 'Title, instructor and categoryId are required'
    });
  }
  const category = categories.find(item => item.id === String(categoryId));
  if (!category) {
    return res.status(400).json({ success: false, message: 'A valid categoryId is required' });
  }
  const course = {
    id: String(Date.now()) + String(Math.floor(Math.random() * 1000)),
    title: String(title).trim(),
    description: description ? String(description).trim() : '',
    instructor: String(instructor).trim(),
    categoryId: category.id,
    categoryName: category.name,
    price: price === undefined ? 0 : Number(price)
  };
  if (!Number.isFinite(course.price) || course.price < 0) {
    return res.status(400).json({ success: false, message: 'Price must be a valid non-negative number' });
  }
  courses.push(course);
  res.status(201).json({ success: true, message: 'Course created successfully', course });
};

exports.getCourses = (req, res) => {
  res.status(200).json({ success: true, count: courses.length, courses });
};

exports.getCourseById = (req, res) => {
  const course = courses.find(item => item.id === req.params.id);
  if (!course) return res.status(404).json({ success: false, message: 'Course not found' });
  res.status(200).json({ success: true, course });
};

exports.updateCourse = (req, res) => {
  const course = courses.find(item => item.id === req.params.id);
  if (!course) return res.status(404).json({ success: false, message: 'Course not found' });
  const { title, description, instructor, categoryId, price } = req.body;
  if (title !== undefined) {
    if (!String(title).trim()) return res.status(400).json({ success: false, message: 'Title cannot be empty' });
    course.title = String(title).trim();
  }
  if (description !== undefined) course.description = String(description).trim();
  if (instructor !== undefined) {
    if (!String(instructor).trim()) return res.status(400).json({ success: false, message: 'Instructor cannot be empty' });
    course.instructor = String(instructor).trim();
  }
  if (categoryId !== undefined) {
    const category = categories.find(item => item.id === String(categoryId));
    if (!category) return res.status(400).json({ success: false, message: 'A valid categoryId is required' });
    course.categoryId = category.id;
    course.categoryName = category.name;
  }
  if (price !== undefined) {
    const numericPrice = Number(price);
    if (!Number.isFinite(numericPrice) || numericPrice < 0) {
      return res.status(400).json({ success: false, message: 'Price must be a valid non-negative number' });
    }
    course.price = numericPrice;
  }
  res.status(200).json({ success: true, message: 'Course updated successfully', course });
};

exports.deleteCourse = (req, res) => {
  const index = courses.findIndex(item => item.id === req.params.id);
  if (index === -1) return res.status(404).json({ success: false, message: 'Course not found' });
  const deleted = courses.splice(index, 1)[0];
  res.status(200).json({ success: true, message: 'Course deleted successfully', course: deleted });
};
