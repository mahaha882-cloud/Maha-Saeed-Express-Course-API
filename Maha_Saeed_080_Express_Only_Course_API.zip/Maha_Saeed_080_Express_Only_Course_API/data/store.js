// In-memory storage only. No database is used.
// Data is reset whenever the server is restarted.
module.exports = {
  users: [],
  categories: [],
  courses: []
};
