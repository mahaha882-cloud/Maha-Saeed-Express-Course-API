const router = require('express').Router();
const controller = require('../controllers/categoryController');
const auth = require('../middleware/authMiddleware');

// Read operations are public; create, update and delete require a JWT.
router.get('/', controller.getCategories);
router.get('/:id', controller.getCategoryById);
router.post('/', auth, controller.createCategory);
router.put('/:id', auth, controller.updateCategory);
router.delete('/:id', auth, controller.deleteCategory);

module.exports = router;
