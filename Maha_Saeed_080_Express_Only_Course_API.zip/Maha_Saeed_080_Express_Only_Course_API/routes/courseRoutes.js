const router = require('express').Router();
const controller = require('../controllers/courseController');
const auth = require('../middleware/authMiddleware');

// Read operations are public; create, update and delete require a JWT.
router.get('/', controller.getCourses);
router.get('/:id', controller.getCourseById);
router.post('/', auth, controller.createCourse);
router.put('/:id', auth, controller.updateCourse);
router.delete('/:id', auth, controller.deleteCourse);

module.exports = router;
